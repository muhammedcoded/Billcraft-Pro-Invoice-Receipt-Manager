# Billcraft Pro | Invoice & Receipt Manager

An elegant, browser-based **invoice and receipt management application** built with **HTML, CSS, and vanilla JavaScript**. Create invoices, record payments, issue receipts, manage customers, and print professional PDF documents, all without a backend or account.

## Features

- **Overview dashboard** showing total invoiced, payments received, outstanding balances, and overdue invoices.
- **Invoice manager:** add multiple items, custom invoice numbers, tax, discount, shipping/fees, payment instructions, due dates, and statuses.
- **Receipt manager:** create standalone receipts or link receipts to invoices. Linked payments automatically reduce outstanding invoice balances.
- **Payment tracking:** full, partial, unpaid, and overdue status, calculated from invoice totals and recorded payments.
- **Client directory:** store customer names, email addresses, phone numbers, and billing addresses for reuse.
- **Live document previews** for invoices and receipts.
- **Save as PDF / Print** using the browser print dialog with a print-friendly A4 layout.
- **Local saving** with `localStorage` and **JSON backup / restore** for portability.
- **Business settings:** company name, address, contact information, bank details, custom notes, and currency.
- **Supported currencies:** USD, NGN, GBP, EUR, CAD, INR, and AUD.
- Mobile-responsive layout. No server, login, Node.js, or database needed to use the application.

## Quick start in VS Code

1. On GitHub, choose **Code > Download ZIP** and extract it. Or clone your repository using the HTTPS URL shown under GitHub's **Code** menu.
2. Open **Visual Studio Code** and select **File > Open Folder**.
3. Select the extracted `billcraft-pro` folder.
4. Double-click `index.html` to open it in Chrome, Edge, Firefox, or Safari.

**That's it.** The app's JavaScript uses ordinary scripts, so opening the HTML file directly works. There is no build step and no installation required.

If you'd prefer a development server in VS Code, install the **Live Server** extension by Ritwick Dey, right-click `index.html`, and choose **Open with Live Server**. The URL is usually `http://127.0.0.1:5500`.

## Getting started

1. Go to **Settings** and enter your business name, contact information, default currency, and payment instructions. Click **Save settings**.
2. Add customers in the **Clients** tab, if you want to reuse their information.
3. Open **Invoices**, select **New invoice**, fill out the invoice details, add line items, and save.
4. Select **View** on an invoice to preview it, then click **Print / Save PDF**. Choose **Save as PDF** as the print destination.
5. When a customer pays, choose **Payment** on the invoice or create a receipt in **Receipts** and link it to the invoice. You can record partial payments.
6. View your outstanding invoices and total payments on the dashboard.
7. Open **Settings > Export backup** regularly. Import the exported JSON to restore data on the same or another browser.

## Project structure

```text
billcraft-pro/
├── index.html
├── assets/
│   ├── app.js         # UI, editors, persistence, print and import/export
│   ├── core.js        # Calculation and validation helpers
│   └── styles.css     # Responsive styling and print layout
├── tests/
│   └── core.test.cjs  # Automated logic tests
├── .gitignore
├── LICENSE
└── README.md
```

## Running tests (optional)

Node.js 18 or newer is required **only** for the tests, not for running the website. From the project folder in the VS Code terminal, run:

```bash
node --test tests/core.test.cjs
```

The tests cover totals, discounts, taxes, balance calculations, invoice statuses, payment matching, input validation, and HTML escaping.

## Deploying to GitHub Pages

1. Create a public repository called `billcraft-pro`.
2. Upload the **contents** of the project folder to the repository, keeping `index.html` at the top level.
3. Open **Settings > Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose `main` and `/(root)`, then **Save**.
6. GitHub will provide the published site URL once deployment finishes.

No backend hosting is required.

## Important limitations and privacy

- Data is saved **only in the current browser's local storage**, so it is **not synchronized** to other browsers or devices. Clearing browser data or using private/incognito mode may lose records. Export backups regularly.
- **No actual payment processing** or bank account verification is provided. A receipt records payment details entered by the user; it does not itself prove that a bank payment occurred.
- Printed documents are saved as PDF through the **browser's print dialog**, not through a PDF API. Appearance may differ slightly by browser or print settings. Disable browser headers/footers in the print dialog for a cleaner PDF.
- All invoice totals and receipts use the **single currency set in Settings**. If you change the currency, existing figures are displayed using the new currency **without exchange-rate conversion**. Avoid mixing currencies in one dataset.
- Tax calculations are simplified: discount is applied before tax. Validate tax rules and invoice requirements for your jurisdiction before using this for official billing.
- Local browser storage is **not encrypted**. Avoid using the application with confidential financial details on a shared device.
- The app is intended as a portfolio/local business tool. For multi-user production billing, a secured backend, user authentication, role permissions, and audit trail would be needed.

## Contributing

Contributions and improvement ideas are welcome. Fork the repository, make a branch, test your changes, and submit a pull request.

## License

MIT License. See [LICENSE](LICENSE).
