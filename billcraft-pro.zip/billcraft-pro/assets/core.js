(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.BillCore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const round = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;
  const money = (n, currency = 'USD') => {
    const symbols = { USD: '$', NGN: '₦', GBP: '£', EUR: '€', CAD: 'CA$', INR: '₹', AUD: 'A$' };
    return (symbols[currency] || currency + ' ') + (Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };
  function calculate(items = [], tax = 0, discount = 0, shipping = 0) {
    const subtotal = round(items.reduce((a, x) => a + round(Math.max(0, Number(x.qty) || 0) * Math.max(0, Number(x.rate) || 0)), 0));
    const discountAmount = round(subtotal * Math.max(0, Math.min(100, Number(discount) || 0)) / 100);
    const taxable = round(subtotal - discountAmount);
    const taxAmount = round(taxable * Math.max(0, Math.min(100, Number(tax) || 0)) / 100);
    const total = round(taxable + taxAmount + Math.max(0, Number(shipping) || 0));
    return { subtotal, discountAmount, taxable, taxAmount, shipping: round(Math.max(0, Number(shipping) || 0)), total };
  }
  function paidAmount(invoice, receipts = []) {
    return round(receipts.filter(r => r.invoiceId === invoice.id).reduce((a, r) => a + (Number(r.amount) || 0), 0));
  }
  function outstanding(invoice, receipts = []) {
    return Math.max(0, round(calculate(invoice.items, invoice.tax, invoice.discount, invoice.shipping).total - paidAmount(invoice, receipts)));
  }
  function invoiceStatus(invoice, receipts = [], today = new Date().toISOString().slice(0, 10)) {
    const total = calculate(invoice.items, invoice.tax, invoice.discount, invoice.shipping).total;
    const paid = paidAmount(invoice, receipts);
    if (total > 0 && paid >= total - 0.005) return 'Paid';
    if (invoice.status === 'Draft') return 'Draft';
    if (invoice.dueDate && invoice.dueDate < today && total > paid) return 'Overdue';
    if (paid > 0) return 'Partial';
    return 'Unpaid';
  }
  function escapeHTML(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]); }
  function validInvoice(x) { return !!(x && typeof x.id === 'string' && typeof x.number === 'string' && Array.isArray(x.items) && x.items.length && x.items.every(i => Number(i.qty) > 0 && Number(i.rate) >= 0) && typeof x.clientName === 'string'); }
  function validReceipt(x) { return !!(x && typeof x.id === 'string' && typeof x.number === 'string' && Number(x.amount) > 0 && typeof x.clientName === 'string'); }
  function nextNumber(prefix, entries) { const nums = entries.map(x => Number(String(x.number).split('-').pop())).filter(Number.isFinite); return prefix + '-' + String(Math.max(0, ...nums) + 1).padStart(4, '0'); }
  function calculateDashboard(invoices = [], receipts = []) {
    let invoiced = 0, outstandingTotal = 0, overdueCount = 0;
    for (const inv of invoices) { invoiced += calculate(inv.items, inv.tax, inv.discount, inv.shipping).total; outstandingTotal += outstanding(inv, receipts); if (invoiceStatus(inv, receipts) === 'Overdue') overdueCount++; }
    return { invoiced: round(invoiced), received: round(receipts.reduce((a, r) => a + Number(r.amount || 0), 0)), outstanding: round(outstandingTotal), overdueCount };
  }
  return { round, money, calculate, paidAmount, outstanding, invoiceStatus, escapeHTML, validInvoice, validReceipt, nextNumber, calculateDashboard };
});
